package com.pmultimedia.proyectof01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Fragment01 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragmento01);
    }
}
