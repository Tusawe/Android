package com.pmultimedia.proyectof06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Fragment06 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment06);
    }
}
