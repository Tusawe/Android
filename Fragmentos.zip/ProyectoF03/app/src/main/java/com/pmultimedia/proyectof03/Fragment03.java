package com.pmultimedia.proyectof03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Fragment03 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment03);
    }
}
