package com.dinterfaces.examen_gomez_joseluis

object EventSingleton {

    val eventos = mutableListOf<Event>()

}